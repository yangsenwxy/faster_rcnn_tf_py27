# --------------------------------------------------------
# R-FCN
# Copyright (c) 2015 Microsoft
# Licensed under The MIT License [see LICENSE for details]
# Revised by Minyue Jiang
# --------------------------------------------------------
